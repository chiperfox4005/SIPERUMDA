<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('peminjaman_ruangans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ruangan_id')->constrained('ruangans');
            $table->foreignId('agenda_id')->nullable()->constrained('agendas');
            $table->foreignId('user_id')->constrained('users');
            $table->date('tanggal_pemakaian');
            $table->time('waktu_mulai');
            $table->time('waktu_selesai');
            $table->text('keperluan');
            $table->integer('jumlah_peserta');
            $table->enum('status_persetujuan', [
                'menunggu', 
                'disetujui', 
                'ditolak', 
                'dibatalkan'
            ])->default('menunggu');
            $table->foreignId('disetujui_oleh')->nullable()->constrained('users');
            $table->text('catatan_penolakan')->nullable();
            $table->softDeletes();
            $table->timestamps();

            $table->index(['ruangan_id', 'tanggal_pemakaian']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('peminjaman_ruangans');
    }
};